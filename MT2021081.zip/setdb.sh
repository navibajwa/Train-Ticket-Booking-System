rm -rf db
mkdir db
touch db/db_train
touch db/db_user
touch db/db_booking

