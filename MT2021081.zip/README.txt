

Run setdb.sh to create essential data files:
    >sh setdb.sh 

gcc -o server server.c
gcc -o client client.c
run the server:
    >./server

run the client:
    >./client

first sign up and create one admin account. 
The secret pin for admin account is "secret".

now login into admin account and add trains.

create customers/agents and login to book ticket.


